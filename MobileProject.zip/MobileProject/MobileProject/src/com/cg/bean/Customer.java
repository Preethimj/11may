package com.cg.bean;

public class Customer {
	
	private String custName;
	private String address;
	private String cellno;
	
	public Customer(String custName, String address, String cellno) {
		super();
		this.custName = custName;
		this.address = address;
		this.cellno = cellno;
	}

	public Customer() {
		super();
		
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCellno() {
		return cellno;
	}

	public void setCellno(String cellno) {
		this.cellno = cellno;
	}

	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", address=" + address + ", cellno=" + cellno + "]";
	}

}
